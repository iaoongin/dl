const apis = [
	'http://api.662820.com/xnflv/index.php?url=',
	'https://api.jpacg.me/player/?url=', //搜狐
	'http://vip.jlsprh.com/index.php?url=' //爱奇艺
]

/**
 * http://api.taoge.la/jiexi/index.php?url=
http://vip.jlsprh.com/index.php?url=
http://api.baiyug.cn/vip/index.php?url=
http://jiexi.92fz.cn/player/vip.php?url=
http://api.nepian.com/ckparse/?url=
http://aikan-tv.com/?url=
http://j.zz22x.com/jx/?url=
http://www.efunfilm.com/yunparse/index.php?url=
https://api.flvsp.com/?url=
http://api.xfsub.com/index.php?url=
http://api.47ks.com/webcloud/?v=
 */