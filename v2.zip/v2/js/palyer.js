function any() {
			var ipt = $('#ipt').val();
			if (!ipt) {
				alert("请输入地址");
			}

			$('#ply').attr('src', apis[2] + ipt);
		}
		ply.onload = function () {
			if (window.screen.width < 700) {
				ply.width = 400;
				ply.height = 300;
			} else {
				ply.width = 640;
				ply.height = 480;
			}
		}